// JavaScript for adding and displaying comments

// Function to add a comment
function addComment(event) {
    event.preventDefault();

    const commentInput = document.getElementById('comment-input');
    const commentText = commentInput.value.trim();

    if (commentText === "") {
        alert("Comment cannot be empty");
        return;
    }

    const commentList = document.getElementById('comment-list');

    // Create a new list item for the comment
    const newComment = document.createElement('li');
    newComment.classList.add('comment');
    newComment.innerText = commentText;

    // Add the new comment to the comment list
    commentList.appendChild(newComment);

    // Clear the input field
    commentInput.value = "";
}

// Add event listener to the comment form
document.addEventListener('DOMContentLoaded', () => {
    const commentForm = document.getElementById('comment-form');
    commentForm.addEventListener('submit', addComment);
});